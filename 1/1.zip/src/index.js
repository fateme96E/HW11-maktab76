

function setThColors() {
    
    let body = document.getElementsByTagName('tbody')[0];

    body.querySelectorAll('tr').forEach((tr) => {
       const td = tr.querySelector('td');
       let color = td.textContent.toLowerCase();
       let bgColor = `bg-${color}`
       tr.setAttribute('class', `${bgColor}`);
    });
}

setThColors();



